import { enableScreens } from 'react-native-screens';
enableScreens();
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createContext, useEffect, useState } from 'react';
import { getUser } from './api';
import { View, ActivityIndicator,Text } from 'react-native';
import tw from 'twrnc';
import LoginScreen from './Page/Auth/LoginScreen';
import RegisterScreen from './Page/Auth/RegisterScreen';
import BottomNavbar from './Component/BottomNavbar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Header from './Component/Header';
import WelcomeScreen from './Page/WelcomeScreen';
import GlobalErrorBoundary from './Component/GlobalErrorBoundary';
import { AuthContext } from './Component/AuthContext';


const Stack = createNativeStackNavigator();

export default function App() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [checkingToken, setCheckingToken] = useState(true);

const checkAuth = async () => {
    setLoading(true);
    setError(null);

    try {
        const token = await AsyncStorage.getItem('userToken');

        if (!token) {
            // Tidak ada token → user dianggap belum login
            setUser(null);
        } else {
            try {
                // Coba ambil data user
                const userData = await getUser(token);
                setUser(userData);
            } catch (err) {
                // Jika gagal karena Unauthenticated → hapus token & set user null
                if (err?.message?.includes('Unauthenticated') || err?.status === 401) {
                    console.warn('Token expired/invalid, menghapus token...');
                    await AsyncStorage.removeItem('userToken');
                }
                setUser(null);
            }
        }
    } catch (err) {
        console.error('Error saat checkAuth:', err);
        setError(err.message || 'Terjadi kesalahan saat memuat data.');
        setUser(null);
    } finally {
        setLoading(false);
        setCheckingToken(false);
    }
};

    // Gunakan useEffect hanya sekali saat aplikasi pertama kali dijalankan
    useEffect(() => {
        checkAuth();
    }, []);


    if (checkingToken) {
        return (
            <View style={tw`flex-1 justify-center items-center bg-gray-100`}>
                <ActivityIndicator size="large" color="#0000ff" />
                <Text style={tw`mt-4 text-lg text-gray-700`}>Memuat aplikasi...</Text>
            </View>
        );
    }
    


    return (
        <GlobalErrorBoundary>
            <AuthContext.Provider value={{ user, setUser }}>
                <NavigationContainer>
                    <Header />
                    <Stack.Navigator screenOptions={{ headerShown: false }}>
                        {!user ? (
                            <>
                                <Stack.Screen name="Welcome" component={WelcomeScreen} />
                                <Stack.Screen name="Login" component={LoginScreen} />
                                <Stack.Screen name="Register" component={RegisterScreen} />
                            </>
                        ) : (
                            <Stack.Screen name="Main" component={BottomNavbar} />
                        )}
                    </Stack.Navigator>
                    <StatusBar style="auto" />
                </NavigationContainer>
            </AuthContext.Provider>
        </GlobalErrorBoundary>
    );
}


