import { useState } from 'react';
import { View, Text, TextInput, Button, Alert, TouchableOpacity, ActivityIndicator } from 'react-native';
import { register } from '../../api';
import tw from 'twrnc';
import { FontAwesome } from '@expo/vector-icons';

export default function RegisterScreen({ navigation }) {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [passwordConfirmation, setPasswordConfirmation] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showPasswordConfirmation, setShowPasswordConfirmation] = useState(false);
    const [isLoading, setIsLoading] = useState(false); // ⬅️ Tambahkan ini

    const handleRegister = async () => {
        if (password !== passwordConfirmation) {
            Alert.alert('Gagal', 'Password dan Konfirmasi Password tidak sama!');
            return;
        }

        setIsLoading(true); // ⬅️ Mulai loading
        try {
            await register({ 
                name, 
                email, 
                password, 
                password_confirmation: passwordConfirmation
            });
            Alert.alert('Berhasil', 'Registrasi sukses!');
            navigation.navigate('Login');
        } catch (error) {
            Alert.alert('Gagal', error.message || 'Registrasi gagal!');
        } finally {
            setIsLoading(false); // ⬅️ Selesai loading
        }
    };

    return (
        <View style={tw`flex-1 items-center justify-center bg-gray-100 p-6`}>  
            <Text style={tw`text-2xl font-bold mb-6`}>Register</Text>
            
            <TextInput
                placeholder="Nama"
                value={name}
                onChangeText={setName}
                style={tw`w-full bg-white p-4 mb-4 rounded-xl shadow-sm`}
            />
            
            <TextInput
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                style={tw`w-full bg-white p-4 mb-4 rounded-xl shadow-sm`}
                keyboardType="email-address"
                autoCapitalize="none"
            />
            
            <View style={tw`w-full bg-white flex-row items-center p-4 mb-4 rounded-xl shadow-sm`}>  
                <TextInput
                    placeholder="Password"
                    value={password}
                    onChangeText={setPassword}
                    style={tw`flex-1`}
                    secureTextEntry={!showPassword}
                />
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                    <FontAwesome name={showPassword ? "eye-slash" : "eye"} size={20} />
                </TouchableOpacity>
            </View>
            
            <View style={tw`w-full bg-white flex-row items-center p-4 mb-6 rounded-xl shadow-sm`}>  
                <TextInput
                    placeholder="Konfirmasi Password"
                    value={passwordConfirmation}
                    onChangeText={setPasswordConfirmation}
                    style={tw`flex-1`}
                    secureTextEntry={!showPasswordConfirmation}
                />
                <TouchableOpacity onPress={() => setShowPasswordConfirmation(!showPasswordConfirmation)}>
                    <FontAwesome name={showPasswordConfirmation ? "eye-slash" : "eye"} size={20} />
                </TouchableOpacity>
            </View>
            
            <View style={tw`w-full mt-2`}>
                {isLoading ? (
                    <ActivityIndicator size="large" color="#4CAF50" />
                ) : (
                    <Button title="Register" onPress={handleRegister} color="#4CAF50" />
                )}
            </View>
            
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                <Text style={tw`text-sm mt-4 text-blue-600`}>Sudah punya akun? Login di sini</Text>
            </TouchableOpacity>
        </View>
    );
}
