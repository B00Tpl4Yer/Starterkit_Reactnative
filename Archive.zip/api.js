import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// const API_URL = 'https://starterkit.proyekk.com/api';
const API_URL = 'http://192.168.1.14/api'; // Jika ingin tes di lokal

// Konfigurasi instance axios
const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
});


// Interceptor untuk menambahkan token otomatis di setiap request
api.interceptors.response.use(response => {
    if (response.data.token) {
        AsyncStorage.setItem('userToken', response.data.token);
        api.defaults.headers.common['Authorization'] = `Bearer ${response.data.token}`;
    }
    return response;
}, error => Promise.reject(error));


// 🔹 Registrasi
export const register = async (data) => {
    try {
        const response = await api.post('/register', data);
        return response.data;
    } catch (error) {
        throw error.response?.data || { message: 'Registrasi gagal!' };
    }
};

// 🔹 Login
export const login = async (data) => {
    try {
        console.log('🔍 Memulai proses login...', data);

        const response = await api.post('/login', data);
        const token = response.data.token;

        if (!token) throw { message: 'Token tidak diterima dari server' };

        // Simpan token ke AsyncStorage
        await AsyncStorage.setItem('userToken', token);
        console.log('🔐 Token tersimpan:', token);

        return response.data;
    } catch (error) {
        console.error('❌ Error saat login:', error.response?.data || error);
        throw error.response?.data || { message: 'Login gagal!' };
    }
};

// 🔹 Logout
export const logout = async () => {
    try {
        const token = await AsyncStorage.getItem('userToken');
        if (!token) {
            console.log('Tidak ada token, langsung logout lokal.');
            return { message: 'Logout lokal' };
        }

        try {
            // Coba logout ke server
            await api.post('/logout', {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            console.log('Logout server berhasil');
        } catch (err) {
            // Kalau token expired/invalid tetap hapus token
            if (err?.response?.status === 401) {
                console.warn('Token invalid saat logout, hapus token lokal.');
            } else {
                console.error('Error logout server:', err);
            }
        }
    } finally {
        // Pastikan token lokal dihapus
        await AsyncStorage.removeItem('userToken');
    }

    return { message: 'Logout berhasil (lokal)' };
};



// 🔹 Mendapatkan data user
export const getUser = async (token = null) => {
    try {
        const headers = token ? { Authorization: `Bearer ${token}` } : {};
        const response = await api.get('/user', { headers });
        return response.data;
    } catch (error) {
        throw error.response?.data || { message: 'Gagal mendapatkan data user!' };
    }
};

// 🔹 Update profil user (name, email, password)
export const updateProfile = async (data) => {
    try {
        const token = await AsyncStorage.getItem('userToken');
        if (!token) throw { message: 'Token tidak tersedia' };

        const response = await api.put('/profile', data, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        return response.data;
    } catch (error) {
        console.error('❌ Error saat update profile:', error.response?.data || error);
        throw error.response?.data || { message: 'Gagal memperbarui profil!' };
    }
};


export default api;
