import React, { Component } from 'react';
import { View, Text, Button, ScrollView } from 'react-native';
import tw from 'twrnc';
import ErrorComponent from './ErrorComponent';

export default class GlobalErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = {
            hasError: false,
            errorMessage: '',
            errorStack: '',
        };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true, errorMessage: error.message || 'Terjadi kesalahan' };
    }

    componentDidCatch(error, errorInfo) {
        console.error('🔥 Error tertangkap oleh GlobalErrorBoundary:', error, errorInfo);
        this.setState({ errorStack: errorInfo.componentStack });
    }

    handleRetry = () => {
        this.setState({ hasError: false, errorMessage: '', errorStack: '' });
    };

    render() {
        if (this.state.hasError) {
            return (
                <View style={tw`flex-1 justify-center items-center bg-white p-6`}>
                    <Text style={tw`text-lg font-bold text-red-600 mb-4`}>Terjadi Kesalahan</Text>
                    <ErrorComponent errorMessage={this.state.errorMessage} onRetry={this.handleRetry} />
                    
                    {this.state.errorStack ? (
                        <ScrollView style={tw`mt-4 p-2 bg-gray-100 rounded-lg w-full`}>
                            <Text style={tw`text-xs text-gray-600`}>{this.state.errorStack}</Text>
                        </ScrollView>
                    ) : null}

                    <Button title="Coba Lagi" onPress={this.handleRetry} />
                </View>
            );
        }

        return this.props.children;
    }
}
