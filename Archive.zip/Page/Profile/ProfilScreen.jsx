import { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView, ActivityIndicator } from 'react-native';
import tw from 'twrnc';
import { getUser, updateProfile } from '../../api';

export default function ProfilScreen({ navigation }) {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [passwordConfirmation, setPasswordConfirmation] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    // Ambil data user saat pertama kali dibuka
    useEffect(() => {
        (async () => {
            try {
                const user = await getUser();
                setName(user.name);
                setEmail(user.email);
            } catch (err) {
                Alert.alert('Gagal mengambil data user', err.message || 'Terjadi kesalahan');
            }
        })();
    }, []);

    const handleUpdate = async () => {
        if (password && password !== passwordConfirmation) {
            return Alert.alert('Error', 'Konfirmasi password tidak cocok.');
        }

        try {
            const data = {
                name,
                email,
                password: password || undefined,
                password_confirmation: passwordConfirmation || undefined,
            };

            const response = await updateProfile(data);
            Alert.alert('Sukses', response.message);
        } catch (error) {
            Alert.alert('Gagal update profil', error.message || 'Terjadi kesalahan');
        }
    };

    return (
        <ScrollView contentContainerStyle={tw`flex-grow justify-center bg-gray-100 p-6`}>
            <View style={tw`bg-white rounded-2xl p-6 shadow`}>
                <Text style={tw`text-2xl font-bold mb-4 text-center`}>Edit Profil</Text>

                <Text style={tw`mb-1 text-gray-700`}>Nama</Text>
                <TextInput
                    style={tw`border border-gray-300 rounded-xl px-4 py-2 mb-4`}
                    value={name}
                    onChangeText={setName}
                />

                <Text style={tw`mb-1 text-gray-700`}>Email</Text>
                <TextInput
                    style={tw`border border-gray-300 rounded-xl px-4 py-2 mb-4`}
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                />

                <Text style={tw`mb-1 text-gray-700`}>Password Baru</Text>
                <TextInput
                    style={tw`border border-gray-300 rounded-xl px-4 py-2 mb-4`}
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                />

                <Text style={tw`mb-1 text-gray-700`}>Konfirmasi Password</Text>
                <TextInput
                    style={tw`border border-gray-300 rounded-xl px-4 py-2 mb-6`}
                    value={passwordConfirmation}
                    onChangeText={setPasswordConfirmation}
                    secureTextEntry
                />
                {isLoading ? (
                    <ActivityIndicator size="large" color="#4CAF50" />
                ) : (
                    <TouchableOpacity
                        onPress={handleUpdate}
                        style={tw`bg-blue-500 rounded-xl py-3`}
                    >
                        <Text style={tw`text-white text-center text-lg font-semibold`}>Simpan Perubahan</Text>
                    </TouchableOpacity>
                )}

            </View>
        </ScrollView>
    );
}
