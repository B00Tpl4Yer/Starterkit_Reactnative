import React, { useContext } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { FontAwesome } from '@expo/vector-icons';
import DashboardScreen from '../Page/DashboardScreen';
import ProfilScreen from '../Page/Profile/ProfilScreen';
import { AuthContext } from './AuthContext';

const Tab = createBottomTabNavigator();

export default function BottomNavbar() {
    const { user } = useContext(AuthContext);

    if (!user) {
        return null; // Jika user tidak ada, jangan tampilkan navbar
    }

    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                tabBarIcon: ({ color, size }) => {
                    let iconName = route.name === 'Home' ? 'home' : 'user';
                    return <FontAwesome name={iconName} size={size} color={color} />;
                },
                tabBarActiveTintColor: '#3B82F6',
                tabBarInactiveTintColor: 'gray',
            })}
        >
            <Tab.Screen name="Home" component={DashboardScreen} />
            <Tab.Screen name="Profile" component={ProfilScreen} />
        </Tab.Navigator>
    );
}