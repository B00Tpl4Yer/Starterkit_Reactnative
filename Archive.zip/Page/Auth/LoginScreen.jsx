import { useState, useContext } from 'react';
import { View, Text, TextInput, Button, Alert, TouchableOpacity, ActivityIndicator } from 'react-native';
import { login } from '../../api';
import { AuthContext } from '../../Component/AuthContext';
import tw from 'twrnc';
import { FontAwesome } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

export default function LoginScreen() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false); // ⬅️ State loading
    const { setUser } = useContext(AuthContext);
    const [showPassword, setShowPassword] = useState(false);
    const navigation = useNavigation();

const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
        Alert.alert('Error', 'Email dan password tidak boleh kosong!');
        return;
    }

    setIsLoading(true); 
    try {
        const response = await login({ email, password });

        setUser(response.user);
        Alert.alert('Berhasil', 'Login sukses!');
    } catch (error) {

            console.error('❌ Login gagal:', error);
            let message = 'Login gagal!';
            const msg = error?.message;

            if (msg === 'These credentials do not match our records.') {
                message = 'Email atau kata sandi Anda salah';
            }

            Alert.alert('Gagal', message);
        } finally {
            setIsLoading(false); // Selesai loading
        }
    };

    return (
        <View style={tw`flex-1 items-center justify-center bg-gray-100 p-6`}>
            <Text style={tw`text-2xl font-bold mb-6 text-red-500`}>Login</Text>

            <TextInput
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                style={tw`w-full bg-white p-4 mb-4 rounded-xl shadow-sm`}
                keyboardType="email-address"
                autoCapitalize="none"
            />
            <View style={tw`w-full bg-white flex-row items-center p-4 mb-4 rounded-xl shadow-sm`}>
                <TextInput
                    placeholder="Password"
                    value={password}
                    onChangeText={setPassword}
                    style={tw`flex-1`}
                    secureTextEntry={!showPassword}
                />
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                    <FontAwesome name={showPassword ? "eye-slash" : "eye"} size={20} />
                </TouchableOpacity>
            </View>

            <View style={tw`w-full mt-2`}>
                {isLoading ? (
                    <ActivityIndicator size="large" color="#4CAF50" />
                ) : (
                    <Button title="Login" onPress={handleLogin} color="#4CAF50" />
                )}
            </View>

            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
                <Text style={tw`text-sm mt-4 text-blue-600`}>Belum punya akun? Daftar di sini</Text>
            </TouchableOpacity>
        </View>
    );
}
