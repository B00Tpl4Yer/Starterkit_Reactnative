import { View, Text, TouchableOpacity } from 'react-native';
import tw from 'twrnc';

export default function WelcomeScreen({ navigation }) {
    return (
        <View style={tw`flex-1 justify-center items-center bg-white`}>
            <Text style={tw`text-2xl font-bold mb-6`}>Selamat Datang di MyApp</Text>

            <TouchableOpacity 
                style={tw`bg-blue-500 px-6 py-3 rounded-lg mb-4`}
                onPress={() => navigation.navigate('Login')}
            >
                <Text style={tw`text-white font-bold`}>Masuk</Text>
            </TouchableOpacity>

            <TouchableOpacity 
                style={tw`border border-blue-500 px-6 py-3 rounded-lg`}
                onPress={() => navigation.navigate('Register')}
            >
                <Text style={tw`text-blue-500 font-bold`}>Daftar</Text>
            </TouchableOpacity>
        </View>
    );
}
