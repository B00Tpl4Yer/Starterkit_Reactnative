import { View, Text, TouchableOpacity } from 'react-native';
import tw from 'twrnc';

const ErrorComponent = ({ errorMessage, onRetry }) => {
    return (
        <View style={tw`justify-center items-center bg-red-100 p-4 rounded-lg`}>
            <Text style={tw`text-red-500 text-lg font-bold`}>Terjadi Error!</Text>
            <Text style={tw`text-red-400 mt-2 text-center`}>{errorMessage}</Text>
            <TouchableOpacity
                style={tw`mt-4 bg-blue-500 px-4 py-2 rounded`}
                onPress={onRetry}
            >
                <Text style={tw`text-white font-bold`}>Coba Lagi</Text>
            </TouchableOpacity>
        </View>
    );
};

export default ErrorComponent;
