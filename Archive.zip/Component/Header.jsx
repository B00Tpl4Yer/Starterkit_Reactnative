import { View, Text, TouchableOpacity, Alert } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import tw from 'twrnc';
import { useContext } from 'react';
import { AuthContext } from './AuthContext';
import { logout } from '../api';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Header() {
    const { user, setUser } = useContext(AuthContext); // Ambil user dari context
    const navigation = useNavigation(); // Gunakan useNavigation

    const handleLogout = async () => {
        Alert.alert(
            "Konfirmasi Logout",
            "Apakah Anda yakin ingin logout?",
            [
                { text: "Batal", style: "cancel" },
                {
                    text: "Logout",
                    onPress: async () => {
                        try {
                            await logout();
                            setUser(null);
                            await AsyncStorage.removeItem('userToken');
                            Alert.alert('Berhasil', 'Logout sukses!');
                            navigation.navigate('Login');
                        } catch (err) {
                            console.error('❌ Logout gagal:', err);
                            Alert.alert('Gagal', 'Logout gagal!');
                        }
                    }
                }
            ]
        );
    };
    

    return (
        <View style={tw`bg-blue-600 py-5 mt-8 px-5 flex-row justify-between items-center`}>
            <Text style={tw`text-white text-lg font-bold`}>MyApp</Text>
            {user && (
                <TouchableOpacity onPress={handleLogout}>
                    <FontAwesome name="sign-out" size={24} color="white" />
                </TouchableOpacity>
            )}
        </View>
    );
}
