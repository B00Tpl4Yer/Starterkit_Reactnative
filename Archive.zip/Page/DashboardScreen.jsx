import { View, Text, Button, Alert } from 'react-native';
import { useEffect, useState, useContext } from 'react';
import { getUser, logout } from '../api';
import tw from 'twrnc';
import { AuthContext } from '../Component/AuthContext';

export default function DashboardScreen({ navigation }) {
    const { user, setUser } = useContext(AuthContext);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const userData = await getUser();
                setUser(userData);
            } catch (error) {
                setUser(null);
            }
        };
        fetchUser();
    }, []);



    return (
        <View style={tw`flex-1 bg-gray-100 p-6 justify-center items-center`}>
            <Text style={tw`text-2xl font-bold mb-6`}>Dashboard</Text>

            {user ? (
                <View style={tw`bg-white p-4 rounded-xl shadow-sm mb-6`}>
                    <Text style={tw`text-lg font-semibold`}>
                        Selamat datang, {user.name}!
                    </Text>
                    <Text style={tw`text-sm text-gray-500`}>Email: {user.email}</Text>
                </View>
            ) : (
                <Text style={tw`text-lg mb-4`}>Anda belum login</Text>
            )}


        </View>
    );
}
